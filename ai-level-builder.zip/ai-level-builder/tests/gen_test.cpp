// Standalone check of the generator: g++ -std=c++20 -Isrc tests/gen_test.cpp src/LevelBuilder.cpp
#include "LevelBuilder.hpp"
#include <cmath>
#include <cstdio>
#include <map>
#include <set>

int main() {
    int failures = 0;
    for (int style = 0; style < lb::STYLE_COUNT; style++) {
        for (int d = 1; d <= 10; d += 3) {
            for (uint32_t seed = 1; seed <= 40; seed++) {
                lb::Settings s;
                s.style = (lb::Style)style; s.difficulty = d; s.seconds = 60; s.seed = seed;
                lb::Request req;
                req.sections = lb::presetSections(s);
                req.theme = lb::presetTheme(s.style);
                req.seed = seed;
                auto res = lb::generate(req);

                // no two solid/hazard objects in the same cell, nothing below ground
                std::set<std::pair<int, int>> blocks, spikes;
                for (auto const& o : res.objs) {
                    if (o.y < 0 || o.x < 0 || std::isnan(o.x) || std::isnan(o.y)) { failures++; std::printf("bad pos\n"); }
                    std::pair<int, int> cell{(int)std::floor(o.x / 30), (int)std::floor(o.y / 30)};
                    if (o.id == 1 && !blocks.insert(cell).second) { failures++; std::printf("dup block style %d d %d seed %u\n", style, d, seed); }
                    if (o.id == 8) spikes.insert(cell);
                }
                for (auto const& c : spikes)
                    if (blocks.count(c)) { failures++; std::printf("spike in block style %d d %d seed %u at %d,%d\n", style, d, seed, c.first, c.second); }
                if (seed == 1)
                    std::printf("%-10s d%-2d sections %zu objects %zu end %.0f blocks\n",
                        lb::styleName(s.style), d, req.sections.size(), res.objs.size(), res.endBlock);
            }
        }
    }
    lb::Settings s;
    std::printf("keywords: %s\n", lb::applyPromptKeywords("long hell wave level, extreme demon, seed 77", s).c_str());
    std::printf("keywords: %s\n", lb::applyPromptKeywords("easy 30s ship level", s).c_str());
    std::printf("sample: %.200s\n", lb::serialize(lb::generate({lb::presetSections(s), lb::presetTheme(s.style)}).objs).c_str());
    std::printf(failures ? "FAILED (%d)\n" : "OK\n", failures);
    return failures != 0;
}
